// 云函数入口文件
const cloud = require('qq-server-sdk')
const express = require('express')
const bodyParser = require('body-parser')
const request = require('request')

const app = express()

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

// 云函数入口函数
exports.main = async (event, context) => {

  const {
    OPENID,
    APPID,
    ENV
  } = cloud.getQQContext()

  return {
    OPENID,
    APPID,
    ENV
  }
}
